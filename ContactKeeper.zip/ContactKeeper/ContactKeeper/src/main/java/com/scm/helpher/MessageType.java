package com.scm.helpher;

public enum MessageType {
 
    blue,red,green,yellow
}
